echo "installing updates ..."
sudo apt install -y screenfetch
