sudo dpkg -i aos-windows-app-support.deb
sudo dpkg -i aos-app-remover.deb
sudo dpkg -i aos-deb-installer.deb
sudo dpkg -i aos-update-manager.deb
sudo dpkg -i aos-welcome.deb
sudo dpkg -i aosver.deb
sudo cp ArchiveOS-en.png /usr/share/wallpapers/ArchiveOS/ArchiveOS-en.png
sudo cp ArchiveOS-tr.png /usr/share/wallpapers/ArchiveOS/ArchiveOS-tr.png
sudo cp -r Remus-Dark /usr/share/icons/Remus-Dark
sudo cp -r Remus-White /usr/share/icons/Remus-White
sudo rm -rf /usr/share/calamares
sudo rm -rf /usr/share/plasma/look-and-feel/org.archiveos.desktop
sudo cp -r org.archiveos.desktop /usr/share/plasma/look-and-feel/org.archiveos.desktop
sudo rm -rf /etc/fastfetch
sudo cp -r fastfetch /etc/fastfetch
sudo rm -rf /etc/ArchiveOS-Logo.txt
sudo cp ArchiveOS-Logo.txt /etc/ArchiveOS-Logo.txt
sudo rm -rf /usr/share/sddm/themes/ArchiveOS
sudo cp -r ArchiveOS /usr/share/sddm/themes/ArchiveOS
sudo rm -rf /usr/share/plymouth/themes/ArchiveOS
sudo cp -r ArchiveOS1 /usr/share/plymouth/themes/ArchiveOS
sudo rm -rf /usr/share/icons/hicolor/256x256/apps/archiveos.png
sudo cp archiveos.png /usr/share/icons/hicolor/256x256/apps/archiveos.png
sudo update-initramfs -u -k all
sudo reboot
