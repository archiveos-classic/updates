echo "installing updates ..."
sudo apt install screenfetch
