/*
 *   SPDX-FileCopyrightText: 2014 Marco Martin <mart@kde.org>
 *   SPDX-License-Identifier: GPL-2.0-or-later
 */

import QtQuick
import org.kde.kirigami 2 as Kirigami

Rectangle {
    id: root
    color: "black"

    property int stage

    onStageChanged: {
        if (stage == 2) {
            introAnimation.running = true;
        } else if (stage == 5) {
            introAnimation.target = busyIndicator;
            introAnimation.from = 1;
            introAnimation.to = 0;
            introAnimation.running = true;
        }
    }

    Item {
        id: content
        anchors.fill: parent
        opacity: 0

        Image {
            id: logo
            readonly property real logoWidth: Kirigami.Units.gridUnit * 18
            readonly property real logoHeight: logoWidth * (673 / 1196)

            anchors.centerIn: parent

            asynchronous: true
            source: "images/aos.png"

            sourceSize.width: logoWidth
            sourceSize.height: logoHeight
        }

        Image {
            id: busyIndicator
            anchors.top: logo.bottom
            anchors.topMargin: Kirigami.Units.largeSpacing
            anchors.horizontalCenter: parent.horizontalCenter

            asynchronous: true
            source: "images/busywidget.svgz"
            sourceSize.height: Kirigami.Units.gridUnit * 2
            sourceSize.width: Kirigami.Units.gridUnit * 2

            RotationAnimator on rotation {
                id: rotationAnimator
                from: 0
                to: 360
                duration: 2000
                loops: Animation.Infinite
                running: Kirigami.Units.longDuration > 1
            }
        }

        // Yeniden Hizalanan Alt Bar (Yazı ve KDE Logosu)
        Row {
            spacing: Kirigami.Units.largeSpacing
            anchors {
                bottom: parent.bottom // Ekranın en altına sabitle
                horizontalCenter: parent.horizontalCenter // ArchiveOS logosuyla aynı dikey çizgide ortala
                bottomMargin: Kirigami.Units.gridUnit * 2 // Ekranın en alt sınırına yapışmaması için 2 birim boşluk
            }
            Text {
                color: "#eff0f1"
                anchors.verticalCenter: parent.verticalCenter
                text: i18ndc("plasma_lookandfeel_org.kde.lookandfeel", "Splash screen text", "Plasma made by KDE")
                Accessible.name: text
                Accessible.role: Accessible.StaticText
            }
            Image {
                asynchronous: true
                source: "images/kde.svgz"
                sourceSize.height: Kirigami.Units.gridUnit * 2
                sourceSize.width: Kirigami.Units.gridUnit * 2
            }
        }
    }

    OpacityAnimator {
        id: introAnimation
        running: false
        target: content
        from: 0
        to: 1
        duration: Kirigami.Units.veryLongDuration * 2
        easing.type: Easing.InOutQuad
    }
}
