loadTemplate("org.kde.plasma.desktop.defaultPanel")

var desktopsArray = desktopsForActivity(currentActivity());
for( var j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = 'org.kde.image';
    desktopsArray[j].currentConfigGroup = Array("Wallpaper", "org.kde.image", "General");
    // Burada hazırladığın dosyanın tam yolunu başına file:// koyarak yazıyoruz
    desktopsArray[j].writeConfig("Image", "file:///usr/share/wallpapers/ArchiveOS/ArchiveOS-en.png");
}
